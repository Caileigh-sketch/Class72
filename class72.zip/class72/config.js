import firebase from 'firebase'

const firebaseConfig = {
  apiKey: "AIzaSyDDhm4NKcKukKorTbrFxB8eXOLBDmRu1f4",
  authDomain: "library-database-43f74.firebaseapp.com",
  projectId: "library-database-43f74",
  storageBucket: "library-database-43f74.appspot.com",
  messagingSenderId: "859758134825",
  appId: "1:859758134825:web:32a806238fde7cc680be38"
};

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  export default firebase.firestore();
